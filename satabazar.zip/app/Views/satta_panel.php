<?=$this->extend("head")?>

<?=$this->section("content")?>



    <button type="button" class="blue-btn my1"> Goto Bottom</button>

    <div class="panel">
        <h1 class="pink-head uppercase"><?= $satta['name'] ?> </h1>
        <table>
            <thead>
                <tr>

                    <th colspan="">date</th>
                    <th colspan="3">mon</th>
                    <th colspan="3">tue</th>
                    <th colspan="3">wed</th>
                    <th colspan="3">thu</th>
                    <th colspan="3">fri</th>
                    <th colspan="3">sat</th>
                    <th colspan="3">sun</th>
                </tr>
                </tr>
            </thead>
            <tbody>


                <?php


                $arrayData = getPanelArrayData($rows);


                // ===========================================================================
                ?>



                <?php foreach($arrayData as $tableRow) { ?>
                    <tr>
                    <td class="dt"> <?= changeFormat($tableRow[0]) ?> <br> to <br><?= changeFormat($tableRow[1]) ?> </td>

                    <?php foreach($tableRow[2] as $cell) { ?>

                        <td class="nb">
                        <?= substr($cell, 0, 1) ?> <br>
                        <?= substr($cell, 1, 1) ?><br>
                        <?= substr($cell, 2, 1) ?><br>
                        </td>
                        <td class="mid"><?= substr($cell, 3, 2) ?></td>
                        <td class="nb">
                        <?= substr($cell, 5, 1) ?><br>
                        <?= substr($cell, 6, 1) ?><br>
                        <?= substr($cell, 7, 1) ?><br>
                        </td>

                  <?php  } ?>

                    </td>

                <?php } ?>

            </tbody>
        </table>
    </div>


</div>

</body>

</html>


<?=$this->endSection()?>