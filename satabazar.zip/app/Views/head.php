<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php

        if( isset($viewdata) ){
            ?>
             <title> <?= $viewdata['title']; ?> </title>
            <?php
        }
        else {
            ?>
            <title> Oldghantabazar.com </title>
           <?php
        }
    
    ?>


    <link rel="stylesheet" href="<?= base_url();?>/public/asset/css/satta.css">
</head>
<body>
<div class="container">
        <h1 class="logo"> <a href="<?= base_url();?>">oldghantabazar</a></h1>

<?= $this->renderSection("content"); ?>
